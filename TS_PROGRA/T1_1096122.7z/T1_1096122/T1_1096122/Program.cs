﻿using System;

namespace T1_1096122
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("------Dolares y quetzales ------------");

            Console.Write("Ingrese el primer monto: ");
            double primerMonto = Convert.ToInt32(Console.ReadLine());
            Console.Write("¿Son dolares(1) o quetzales(2)?:");
            string option = Convert.ToString(Console.ReadLine());

            if (option == "USD")
            {
                primerMonto = primerMonto * 7.83;
            }

            Console.Write("Ingrese el segundo monto: ");
            double segundoMonto = Convert.ToInt32(Console.ReadLine());
            Console.Write("¿Son dolares(1) o quetzales(2)?:");
            option = Convert.ToString(Console.ReadLine());

            if (option == "USD")
            {
                segundoMonto = primerMonto * 7.83;
            }

            Console.Write("Ingrese el tercer monto: ");
            double tercerMonto = Convert.ToInt32(Console.ReadLine());
            Console.Write("¿Son dolares(1) o quetzales(2)?:");
            option = Convert.ToString(Console.ReadLine());

            if (option == "USD")
            {
                tercerMonto = primerMonto * 7.83;
            }

            if ((primerMonto > segundoMonto) && (primerMonto > tercerMonto))
            {
                Console.WriteLine("Q" + primerMonto);
                if (segundoMonto > tercerMonto)
                {
                    Console.WriteLine("Q" + segundoMonto);
                    Console.WriteLine("Q" + tercerMonto);
                } else
                {
                    Console.WriteLine("Q" + tercerMonto);
                    Console.WriteLine("Q" + segundoMonto);
                }
            }
            else
            {
                if ((segundoMonto > tercerMonto))
                {
                    Console.WriteLine("Q" + segundoMonto);
                    if (primerMonto > tercerMonto)
                    {
                        Console.WriteLine("Q" + primerMonto);
                        Console.WriteLine("Q" + tercerMonto);
                    }
                    else
                    {
                        Console.WriteLine("Q" + tercerMonto);
                        Console.WriteLine("Q" + primerMonto);
                    }
                }
                else
                {
                    Console.WriteLine("Q" + tercerMonto);
                    if((primerMonto > segundoMonto))
                {
                        
              
                            Console.WriteLine("Q" + primerMonto);
                            Console.WriteLine("Q" + segundoMonto);
                        }
                        else
                        {
                            Console.WriteLine("Q" + segundoMonto);
                            Console.WriteLine("Q" + primerMonto);
                        }
                    }


                Console.ReadLine();


                }
            }
        }
    }

