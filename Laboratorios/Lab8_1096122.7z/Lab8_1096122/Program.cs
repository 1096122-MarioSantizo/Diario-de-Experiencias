﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab8_1096122
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("----------------------------Ejercicio 1------------------------------");
            Console.WriteLine("Ingrese el numero de mes:");
            int mes = int.Parse(Console.ReadLine());

            if (mes <1 || mes > 12)
            {
                Console.WriteLine("Error: El numero a ingresar");
            }
            else
            {
                switch (mes)
                {
                    case 1:
                        Console.WriteLine("El mes es Enero");
                        break;
                    case 2:
                        Console.WriteLine("El mes es Febrero");
                        break;
                    case 3:
                        Console.WriteLine("El mes es Marzo");
                        break;
                    case 4:
                        Console.WriteLine("El mes es Abril");
                        break;
                    case 5:
                        Console.WriteLine("El mes es Mayo");
                        break;
                    case 6:
                        Console.WriteLine("El mes es Junio");
                        break;
                    case 7:
                        Console.WriteLine("El mes es Julio");
                        break;
                    case 8:
                        Console.WriteLine("El mes es Agosto");
                        break;
                    case 9:
                        Console.WriteLine("El mes es Septiembre");
                        break;
                    case 10:
                        Console.WriteLine("El mes es Octubre");
                        break;
                    case 11:
                        Console.WriteLine("El mes es Noviembre");
                        break;
                    case 12:
                        Console.WriteLine("El mes es Diciembre");
                        break;

                }
            }
            Console.ReadKey();
        }
    }
}
