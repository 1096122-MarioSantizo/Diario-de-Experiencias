﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace S9_1096122
{
    class Circulo
    {
        private double radio;

        public Circulo( double radio)
        {
            this.radio = radio;
        }

        public double ObtenerPerimetro ()
        {
            return 2 * Math.PI * radio;
        }

        public double ObtenerArea ()
        {
            return Math.PI * radio * radio;
        }

        public double ObtenerVolumen ()
        {
            return 4 / 3 * Math.PI * Math.Pow(radio, 3);
        }

        public void CalcularGeometria(double unPerimetro, double unArea, double unVolumen)
        {
            Console.WriteLine("Perimetro: " + unPerimetro);
            Console.WriteLine("Area: " +  unArea);
            Console.WriteLine("Vloumen: " + unVolumen);
        }
    }
}
