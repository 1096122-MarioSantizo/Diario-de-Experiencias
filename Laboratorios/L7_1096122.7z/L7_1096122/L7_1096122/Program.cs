﻿using System;

namespace L7_1096122
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.ReadKey();

  
            Console.WriteLine("Dime tu nombre");
            string nombre = Console.ReadLine();
            Console.WriteLine("Te llamas" + nombre);

            Console.ReadKey();

  
            
       
        }
    }
}
