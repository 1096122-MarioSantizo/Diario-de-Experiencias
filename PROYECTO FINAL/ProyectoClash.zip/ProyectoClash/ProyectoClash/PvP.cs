﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoClash
{
    public partial class PvP : Form
    {
        public PvP()
        {
            InitializeComponent();
        }
        

        public string var1 = "inicio";
        public string var2 = "inicio";
        
        

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ha seleccionado el mazo " + "'Dos con seis'");
            MessageBox.Show("Selecciona un mazo por favor", "Jugador 2");
            var1 = "dosconseis";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            groupBox1.Enabled = true;
            MessageBox.Show("Selecciona un mazo por favor", "Jugador 1");
            
            groupBox2.Enabled = true;
        }

        private void btnSubeCopas_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ha seleccionado el mazo " + "'SubeCopas'");
            MessageBox.Show("Selecciona un mazo por favor", "Jugador 2");
            var1 = "subecopas";
        }

        private void btnMinero_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ha seleccionado el mazo " + "'MinerControl'");
            var2 = "minercontrol";
            
        }

        private void btnLava_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ha seleccionado el mazo " + "'LavaLoon'");
            var2 = "lavaloon";
        }

        

        private void btnComparar_Click(object sender, EventArgs e)
        {
            Mazos m = new Mazos();
            
            if (var1 == "dosconseis")
            {
                txtDaño1.Text = "2002";
                txtVida1.Text = "4748";
                lblDefensa1.Text = "La defensa de este mazo" + Environment.NewLine +
                "es muy buena ya que" + Environment.NewLine +
                "cuenta con cartas" +
                "balanceadas";
                lblBalance1.Text = "El balance de este mazo" + Environment.NewLine +
                "es casi perfecto debido" +
                "a que puede realizar" + Environment.NewLine +
                "un buen ataque y una" + Environment.NewLine+
                "buena defensa";
            }
            else if(var1 == "subecopas")
            {
                txtDaño1.Text = "2361";
                txtVida1.Text = "7174";
                lblDefensa1.Text = "La defensa de este mazo" + Environment.NewLine +
                "es buena aunque podria" + Environment.NewLine +
                "ser mejor y mas" +Environment.NewLine+
                "eficiente";
                lblBalance1.Text = "El balance de este mazo" + Environment.NewLine +
                "es medio debido a" + Environment.NewLine +
                "que tiene cartas un poco" + Environment.NewLine +
                "costosas, aunque su ataque" + Environment.NewLine+
                "sea poderoso";
            }

            if(var2 == "minercontrol")
            {
                txtDaño2.Text = "1748";
                txtVida2.Text = "5470";
                lblDefensa2.Text = "La defensa de este mazo" + Environment.NewLine +
                "es muy eficiente con" + Environment.NewLine +
                "la cual se puede armar" + Environment.NewLine +
                "un fuerte contraataque" + Environment.NewLine;
                lblBalance2.Text = "El balance de este mazo" + Environment.NewLine +
                "es perfecto debido a que" +Environment.NewLine+
                "tiene cartas baratas que" + Environment.NewLine +
                "son muy efectivas tanto" + Environment.NewLine +
                "en ataque como en defensa" + Environment.NewLine;
            }
            else if(var2 == "lavaloon")
            {
                txtDaño2.Text = "2834";
                txtVida2.Text = "8291";
                lblDefensa2.Text = "La defensa de este mazo" + Environment.NewLine +
                "sufriria contra mazos" + Environment.NewLine+
                "terrestres por lo que" + Environment.NewLine +
                "se debe jugar con cabeza";
                lblBalance2.Text = "El balance de este mazo" + Environment.NewLine +
                "es medio debido a que" + Environment.NewLine+
                "tiene cartas un poco" + Environment.NewLine +
                "costosas, aunque su" + Environment.NewLine +
                "ataque sea poderoso";
            }
            int cont1 = 0, cont2 = 0;
            int daño1 = Convert.ToInt16(txtDaño1.Text);
            int vida1 = Convert.ToInt16(txtVida1.Text);
            int daño2 = Convert.ToInt16(txtDaño2.Text);
            int vida2 = Convert.ToInt16(txtVida2.Text);
            if(daño1 > daño2)
            {
                MessageBox.Show("El mazo del jugador 1 es superior en daño", "Alerta");
                cont1++;
                if(vida1 > vida2)
                {
                    MessageBox.Show("El mazo del jugador 1 es superior en vida", "Alerta");
                    cont1++;
                }
                else
                {
                    MessageBox.Show("El mazo del jugador 2 es superior en vida", "Alerta");
                    cont2++;
                }
            }
            else
            {
                MessageBox.Show("El mazo del jugador 2 es superior en daño", "Alerta");
                cont2++;
                if (vida1 > vida2)
                {
                    MessageBox.Show("El mazo del jugador 1 es superior en vida", "Alerta");
                    cont1++;
                }
                else
                {
                    MessageBox.Show("El mazo del jugador 2 es superior en vida", "Alerta");
                    cont2++;
                }
            }
            if(cont1 > cont2)
            {
                MessageBox.Show("El mazo del jugador 1 tiene mas probabilidades de ganar", "Conclusion");
            }
            else
            {
                MessageBox.Show("El mazo del jugador 2 tiene mas probabilidades de ganar", "Conclusion");
            }

        }
    }
}
