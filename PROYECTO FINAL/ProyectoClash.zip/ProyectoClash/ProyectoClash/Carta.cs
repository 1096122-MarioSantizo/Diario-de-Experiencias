﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoClash
{
    public class Carta
    {
        

        public Carta(string name, int vida, int daño)
        {
            Nombre = name;
            PuntosVida = vida;
            Daño = daño;
        }

        public string Nombre  { get;}
        public int PuntosVida { get; set; }
        public int Daño { get; set; }

    }
}
