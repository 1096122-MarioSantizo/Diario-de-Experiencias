﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoClash
{
    public partial class Mazos : Form
    {
        public Mazos()
        {
            InitializeComponent();

            
        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            //Creando las cartas que se utilizaran
            Carta montapuerco = new Carta("montapuerco", 1696, 318);
            Carta tronco = new Carta("Tronco", 0, 290*2);
            Carta mosquetera = new Carta("Mosquetera", 720, 218);
            Carta espirituHielo = new Carta("Espiritu de Hielo", 230, 110);
            Carta golemHielo = new Carta("Golem de Hielo", 1197, 84);
            Carta bolaFuego = new Carta("Bola de Fuego", 0, 689*2);
            Carta cañon = new Carta("Cañon", 824*2, 212);
            Carta esqueletos = new Carta("Esqueletos", 81, 81);
            Carta torrebombardera = new Carta("Torre Bombardera", 1356*2, 222);
            Carta arqueromagico = new Carta("Arquero Magico", 532, 134);
            Carta minero = new Carta("Minero", 1210, 193);
            Carta duendesclanza = new Carta("Duendes con lanza", 133, 81);
            Carta tornado = new Carta("Tornado", 0, 169*2);
            Carta valquiria = new Carta("Valquiria", 1908, 267);
            Carta rompemuros = new Carta("Rompemuros", 331, 392);
            Carta murcielagos = new Carta("Murcielagos", 81, 81);
            Carta sabueso = new Carta("Sabueso de lava", 3811, 54);
            Carta princesa = new Carta("Princesa", 261, 169);
            Carta globo = new Carta("Globo Bombastico", 1680, 640);
            Carta minipekka = new Carta("Mini PEKKA", 1361, 720);
            Carta veneno = new Carta("Veneno", 0, 728*2);
            Carta megaesbirro = new Carta("Mega esbirro", 837, 311);
            Carta lanzadardos = new Carta("Duende lanzadardos", 260, 131);
            Carta gigante = new Carta("Gigante", 4091, 254);
            Carta bandida = new Carta("Bandida", 907, 193);
            Carta esbirros = new Carta("Esbirros", 230, 102);
            Carta babydragon = new Carta("Bebe dragon", 1152, 160);
            Carta magoelectrico = new Carta("Mago Electrico", 713, 225);
            Carta rayo = new Carta("Rayo", 0, 1056*2);

            
            //Agregando las cartas a los mazos
            Carta[] eldosconseis = {montapuerco, tronco, mosquetera, espirituHielo, golemHielo, bolaFuego, cañon, esqueletos };
            Carta[] minerocont = { torrebombardera, arqueromagico, minero, duendesclanza, tronco, tornado, valquiria, rompemuros};
            Carta[] laval = { murcielagos, sabueso, princesa, globo, minipekka, veneno, megaesbirro, lanzadardos };
            Carta[] copas = { gigante, esqueletos, tronco, bandida, esbirros, babydragon, magoelectrico, rayo };

            //Creando las 4 instancias de la clase Deck con el nombre que creamos en el excel
            Deck dosconseis = new Deck("Eldosconseis", eldosconseis);
            Deck minercontrol = new Deck("Minercontrol",minerocont);
            Deck lavaloon = new Deck("Lavaloon", laval);
            Deck subecopas = new Deck("Subecopas", copas);
            //creacion de variables que almacenan el daño y los puntos de vida del mazo dosconseis
            int suma = dosconseis.GetDañoTotal(eldosconseis);
            int vida = dosconseis.GetPuntosDeVida(eldosconseis);
            //Propiedades del mazo dosconseis
            txtDañoSeis.Text = Convert.ToString(suma);
            txtVidaSeis.Text = Convert.ToString(vida);
            lblDefensa.Text = "La defensa de" + Environment.NewLine+
                "este mazo es" + Environment.NewLine+
                "muy buena ya que" + Environment.NewLine+
                "cuenta con " + Environment.NewLine+
                "cartas balanceadas";
            lblBalance.Text = "El balance de este" + Environment.NewLine +
                "mazo" + 
                "es casi perfecto" + Environment.NewLine+
                "debido a que puede " + Environment.NewLine+
                "realizar un buen" + Environment.NewLine+
                "ataque y una buena" +Environment.NewLine+
                "defensa";
            //Se muestra el nombre de cada carta con su imagen del mazo dosconseis
            lblMonta.Text = dosconseis.Cartas[0].Nombre;
            lblTronco.Text = dosconseis.Cartas[1].Nombre;
            lblMosquetera.Text = dosconseis.Cartas[2].Nombre;
            lblEspiritu.Text = dosconseis.Cartas[3].Nombre;
            lblGolem.Text = dosconseis.Cartas[4].Nombre;
            lblBola.Text = dosconseis.Cartas[5].Nombre;
            lblCañon.Text = dosconseis.Cartas[6].Nombre;
            lblEsqueleto.Text = dosconseis.Cartas[7].Nombre;
            pictureBox1.Visible = true;
            pictureBox2.Visible = true;
            pictureBox3.Visible = true;
            pictureBox4.Visible = true;
            pictureBox5.Visible = true;
            pictureBox6.Visible = true;
            pictureBox7.Visible = true;
            pictureBox8.Visible = true;
            //Se muestra el nombre de cada carta con su imagen del mazo subecopas
            lblGigante.Text = subecopas.Cartas[0].Nombre;
            lblEsque.Text = subecopas.Cartas[1].Nombre;
            lblTron.Text = subecopas.Cartas[2].Nombre;
            lblBandida.Text = subecopas.Cartas[3].Nombre;
            lblEsbirros.Text = subecopas.Cartas[4].Nombre;
            lblBaby.Text = subecopas.Cartas[5].Nombre;
            lblMago.Text = subecopas.Cartas[6].Nombre;
            lblRayo.Text = subecopas.Cartas[7].Nombre;
            pictureBox9.Visible = true;
            pictureBox10.Visible = true;
            pictureBox11.Visible = true;
            pictureBox12.Visible = true;
            pictureBox13.Visible = true;
            pictureBox14.Visible = true;
            pictureBox15.Visible = true;
            pictureBox16.Visible = true;
            //creacion de variables que almacenan el daño y los puntos de vida del mazo subecopa
            int sumaSubecopas = subecopas.GetDañoTotal(copas);
            int vidaSubecopas = subecopas.GetPuntosDeVida(copas);
            string defensaSube = "La defensa de" + Environment.NewLine +
                "este mazo es" + Environment.NewLine +
                "buena aunque podria" + Environment.NewLine +
                "ser mejor y" + Environment.NewLine +
                "mas eficiente";
            string balanceSube = "El balance de esteALIHAFAOFOHFOASEHFOIASFHOIAFHOIFHOIAHEOI" + Environment.NewLine +
                "mazo" +
                "es medio" + Environment.NewLine +
                "debido a que tiene" + Environment.NewLine +
                "cartas un poco" + Environment.NewLine +
                "costosas, aunque su" + Environment.NewLine +
                "ataque sea poderoso";
            //Propiedades del mazo subecopa
            lblDañoSube.Text = Convert.ToString(sumaSubecopas);
            lblVidaSube.Text = Convert.ToString(vidaSubecopas);
            lblDefensaSube.Text = defensaSube;
            lblBalanceSube.Text = balanceSube;
            



            //Se muestra el nombre de cada carta con su imagen del mazo minercontrol
            lblTorre.Text = minercontrol.Cartas[0].Nombre;
            lblArquero.Text = minercontrol.Cartas[1].Nombre;
            lblMinero.Text = minercontrol.Cartas[2].Nombre;
            lblDuendes.Text = minercontrol.Cartas[3].Nombre;
            lbltroncus.Text = minercontrol.Cartas[4].Nombre;
            lblTornado.Text = minercontrol.Cartas[5].Nombre;
            lblValquiria.Text = minercontrol.Cartas[6].Nombre;
            lblRompe.Text = minercontrol.Cartas[7].Nombre;
            pictureBox17.Visible = true;
            pictureBox18.Visible = true;
            pictureBox19.Visible = true;
            pictureBox20.Visible = true;
            pictureBox21.Visible = true;
            pictureBox22.Visible = true;
            pictureBox23.Visible = true;
            pictureBox24.Visible = true;
            //creacion de variables que almacenan el daño y los puntos de vida del mazo minercontrol
            int sumaMineroc = minercontrol.GetDañoTotal(minerocont);
            int vidaMineroc = minercontrol.GetPuntosDeVida(minerocont);
            //Propiedades del mazo minercontrol
            lblDañoMinero.Text = Convert.ToString(sumaMineroc);
            lblVidaMinero.Text = Convert.ToString(vidaMineroc);
            lblDefensaMinero.Text = "La defensa de" + Environment.NewLine +
                "este mazo es" + Environment.NewLine +
                "muy eficiente con" + Environment.NewLine +
                "la cual se puede" + Environment.NewLine +
                "armar un fuerte" + Environment.NewLine+
                "contraataque";
            lblBalanceMinero.Text = "El balance de este" + Environment.NewLine +
                "mazo" +
                " es perfecto" + Environment.NewLine +
                "debido a que tiene" + Environment.NewLine +
                "cartas baratas que" + Environment.NewLine +
                "son muy efectivas" + Environment.NewLine +
                "tanto en ataque" + Environment.NewLine+
                "como en defensa";

            //Se muestra el nombre de cada carta con su imagen del mazo lavaloon
            lblMurcielago.Text = lavaloon.Cartas[0].Nombre;
            lblSabueso.Text = lavaloon.Cartas[1].Nombre;
            lblPrincesa.Text = lavaloon.Cartas[2].Nombre;
            lblGlobo.Text = lavaloon.Cartas[3].Nombre;
            lblMini.Text = lavaloon.Cartas[4].Nombre;
            lblVeneno.Text = lavaloon.Cartas[5].Nombre;
            lblMega.Text = lavaloon.Cartas[6].Nombre;
            lblLanzad.Text = lavaloon.Cartas[7].Nombre;
            pictureBox25.Visible = true;
            pictureBox26.Visible = true;
            pictureBox27.Visible = true;
            pictureBox28.Visible = true;
            pictureBox29.Visible = true;
            pictureBox30.Visible = true;
            pictureBox31.Visible = true;
            pictureBox32.Visible = true;
            //creacion de variables que almacenan el daño y los puntos de vida del mazo subecopa
            int sumaLavaloon = minercontrol.GetDañoTotal(laval);
            int vidaLavaloon = minercontrol.GetPuntosDeVida(laval);
            //Propiedades del mazo subecopa
            lblDañoLava.Text = Convert.ToString(sumaLavaloon);
            lblVidaLava.Text = Convert.ToString(vidaLavaloon);
            lblDefensaLava.Text = "La defensa de " + Environment.NewLine +
                "este mazo" + Environment.NewLine +
                "sufriria contra" + Environment.NewLine +
                "mazos terrestres por" + Environment.NewLine +
                "lo que se debe" +Environment.NewLine+
                "jugar con cabeza";
            lblBalanceLava.Text = "El balance de este" + Environment.NewLine +
                "mazo" +
                "es medio" + Environment.NewLine +
                "debido a que tiene" + Environment.NewLine +
                "cartas un poco" + Environment.NewLine +
                "costosas, aunque su" + Environment.NewLine +
                "ataque sea poderoso";
            
            
        }
        
        

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void tabPage4_Click(object sender, EventArgs e)
        {

        }

        private void btnPvP_Click(object sender, EventArgs e)
        {
            PvP pvp = new PvP();
            pvp.Show();
        }
    }
}
