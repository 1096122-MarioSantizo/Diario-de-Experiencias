﻿namespace ProyectoClash
{
    partial class PvP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblBalance1 = new System.Windows.Forms.Label();
            this.lblDefensa1 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSubeCopas = new System.Windows.Forms.Button();
            this.btnDoscSeis = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnLava = new System.Windows.Forms.Button();
            this.btnMinero = new System.Windows.Forms.Button();
            this.btnComparar = new System.Windows.Forms.Button();
            this.txtDaño1 = new System.Windows.Forms.TextBox();
            this.txtVida1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblDefensa2 = new System.Windows.Forms.Label();
            this.lblBalance2 = new System.Windows.Forms.Label();
            this.txtDaño2 = new System.Windows.Forms.TextBox();
            this.txtVida2 = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Sienna;
            this.groupBox1.Controls.Add(this.txtVida1);
            this.groupBox1.Controls.Add(this.txtDaño1);
            this.groupBox1.Controls.Add(this.lblBalance1);
            this.groupBox1.Controls.Add(this.lblDefensa1);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnSubeCopas);
            this.groupBox1.Controls.Add(this.btnDoscSeis);
            this.groupBox1.Enabled = false;
            this.groupBox1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox1.Location = new System.Drawing.Point(12, 58);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(308, 352);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Jugador 1";
            // 
            // lblBalance1
            // 
            this.lblBalance1.AutoSize = true;
            this.lblBalance1.BackColor = System.Drawing.Color.Sienna;
            this.lblBalance1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBalance1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblBalance1.Location = new System.Drawing.Point(100, 249);
            this.lblBalance1.Name = "lblBalance1";
            this.lblBalance1.Size = new System.Drawing.Size(16, 18);
            this.lblBalance1.TabIndex = 13;
            this.lblBalance1.Text = "|";
            // 
            // lblDefensa1
            // 
            this.lblDefensa1.AutoSize = true;
            this.lblDefensa1.BackColor = System.Drawing.Color.Sienna;
            this.lblDefensa1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDefensa1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblDefensa1.Location = new System.Drawing.Point(98, 162);
            this.lblDefensa1.Name = "lblDefensa1";
            this.lblDefensa1.Size = new System.Drawing.Size(16, 18);
            this.lblDefensa1.TabIndex = 14;
            this.lblDefensa1.Text = "|";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Sienna;
            this.label18.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label18.Location = new System.Drawing.Point(97, 232);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(57, 18);
            this.label18.TabIndex = 11;
            this.label18.Text = "Balance:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Sienna;
            this.label17.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label17.Location = new System.Drawing.Point(97, 145);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(60, 18);
            this.label17.TabIndex = 12;
            this.label17.Text = "Defensa:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Sienna;
            this.label16.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label16.Location = new System.Drawing.Point(142, 107);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(99, 18);
            this.label16.TabIndex = 9;
            this.label16.Text = "Puntos de vida:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Sienna;
            this.label9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label9.Location = new System.Drawing.Point(144, 68);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 18);
            this.label9.TabIndex = 10;
            this.label9.Text = "Daño:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Sienna;
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(143, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 18);
            this.label1.TabIndex = 6;
            this.label1.Text = "Propiedades:";
            // 
            // btnSubeCopas
            // 
            this.btnSubeCopas.Location = new System.Drawing.Point(6, 96);
            this.btnSubeCopas.Name = "btnSubeCopas";
            this.btnSubeCopas.Size = new System.Drawing.Size(120, 33);
            this.btnSubeCopas.TabIndex = 1;
            this.btnSubeCopas.Text = "SubeCopas";
            this.btnSubeCopas.UseVisualStyleBackColor = true;
            this.btnSubeCopas.Click += new System.EventHandler(this.btnSubeCopas_Click);
            // 
            // btnDoscSeis
            // 
            this.btnDoscSeis.Location = new System.Drawing.Point(6, 34);
            this.btnDoscSeis.Name = "btnDoscSeis";
            this.btnDoscSeis.Size = new System.Drawing.Size(120, 33);
            this.btnDoscSeis.TabIndex = 0;
            this.btnDoscSeis.Text = "ElDosconSeis";
            this.btnDoscSeis.UseVisualStyleBackColor = true;
            this.btnDoscSeis.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(250, 23);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(123, 30);
            this.button1.TabIndex = 1;
            this.button1.Text = "EMPEZAR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Sienna;
            this.groupBox2.Controls.Add(this.txtVida2);
            this.groupBox2.Controls.Add(this.txtDaño2);
            this.groupBox2.Controls.Add(this.btnLava);
            this.groupBox2.Controls.Add(this.lblBalance2);
            this.groupBox2.Controls.Add(this.btnMinero);
            this.groupBox2.Controls.Add(this.lblDefensa2);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Enabled = false;
            this.groupBox2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(326, 59);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(322, 351);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Jugador 2";
            // 
            // btnLava
            // 
            this.btnLava.Location = new System.Drawing.Point(6, 95);
            this.btnLava.Name = "btnLava";
            this.btnLava.Size = new System.Drawing.Size(104, 33);
            this.btnLava.TabIndex = 1;
            this.btnLava.Text = "LavaLoon";
            this.btnLava.UseVisualStyleBackColor = true;
            this.btnLava.Click += new System.EventHandler(this.btnLava_Click);
            // 
            // btnMinero
            // 
            this.btnMinero.Location = new System.Drawing.Point(6, 30);
            this.btnMinero.Name = "btnMinero";
            this.btnMinero.Size = new System.Drawing.Size(104, 36);
            this.btnMinero.TabIndex = 0;
            this.btnMinero.Text = "MinerControl";
            this.btnMinero.UseVisualStyleBackColor = true;
            this.btnMinero.Click += new System.EventHandler(this.btnMinero_Click);
            // 
            // btnComparar
            // 
            this.btnComparar.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnComparar.Location = new System.Drawing.Point(250, 416);
            this.btnComparar.Name = "btnComparar";
            this.btnComparar.Size = new System.Drawing.Size(123, 33);
            this.btnComparar.TabIndex = 2;
            this.btnComparar.Text = "Comparar";
            this.btnComparar.UseVisualStyleBackColor = true;
            this.btnComparar.Click += new System.EventHandler(this.btnComparar_Click);
            // 
            // txtDaño1
            // 
            this.txtDaño1.Location = new System.Drawing.Point(145, 84);
            this.txtDaño1.Name = "txtDaño1";
            this.txtDaño1.Size = new System.Drawing.Size(100, 23);
            this.txtDaño1.TabIndex = 15;
            // 
            // txtVida1
            // 
            this.txtVida1.Location = new System.Drawing.Point(145, 123);
            this.txtVida1.Name = "txtVida1";
            this.txtVida1.Size = new System.Drawing.Size(100, 23);
            this.txtVida1.TabIndex = 16;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Sienna;
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(145, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 18);
            this.label2.TabIndex = 6;
            this.label2.Text = "Propiedades:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Sienna;
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(146, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 18);
            this.label3.TabIndex = 10;
            this.label3.Text = "Daño:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Sienna;
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(144, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 18);
            this.label4.TabIndex = 9;
            this.label4.Text = "Puntos de vida:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Sienna;
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(95, 144);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 18);
            this.label5.TabIndex = 12;
            this.label5.Text = "Defensa:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Sienna;
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Location = new System.Drawing.Point(91, 231);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 18);
            this.label6.TabIndex = 11;
            this.label6.Text = "Balance:";
            // 
            // lblDefensa2
            // 
            this.lblDefensa2.AutoSize = true;
            this.lblDefensa2.BackColor = System.Drawing.Color.Sienna;
            this.lblDefensa2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDefensa2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblDefensa2.Location = new System.Drawing.Point(96, 161);
            this.lblDefensa2.Name = "lblDefensa2";
            this.lblDefensa2.Size = new System.Drawing.Size(16, 18);
            this.lblDefensa2.TabIndex = 14;
            this.lblDefensa2.Text = "|";
            // 
            // lblBalance2
            // 
            this.lblBalance2.AutoSize = true;
            this.lblBalance2.BackColor = System.Drawing.Color.Sienna;
            this.lblBalance2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBalance2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblBalance2.Location = new System.Drawing.Point(94, 248);
            this.lblBalance2.Name = "lblBalance2";
            this.lblBalance2.Size = new System.Drawing.Size(16, 18);
            this.lblBalance2.TabIndex = 13;
            this.lblBalance2.Text = "|";
            // 
            // txtDaño2
            // 
            this.txtDaño2.Location = new System.Drawing.Point(147, 83);
            this.txtDaño2.Name = "txtDaño2";
            this.txtDaño2.Size = new System.Drawing.Size(100, 23);
            this.txtDaño2.TabIndex = 15;
            // 
            // txtVida2
            // 
            this.txtVida2.Location = new System.Drawing.Point(147, 122);
            this.txtVida2.Name = "txtVida2";
            this.txtVida2.Size = new System.Drawing.Size(100, 23);
            this.txtVida2.TabIndex = 16;
            // 
            // PvP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(660, 453);
            this.Controls.Add(this.btnComparar);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "PvP";
            this.Text = "PvP";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnDoscSeis;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnSubeCopas;
        private System.Windows.Forms.Button btnLava;
        private System.Windows.Forms.Button btnMinero;
        private System.Windows.Forms.Button btnComparar;
        private System.Windows.Forms.Label lblBalance1;
        private System.Windows.Forms.Label lblDefensa1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox txtVida1;
        public System.Windows.Forms.TextBox txtDaño1;
        public System.Windows.Forms.TextBox txtVida2;
        public System.Windows.Forms.TextBox txtDaño2;
        private System.Windows.Forms.Label lblBalance2;
        private System.Windows.Forms.Label lblDefensa2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
    }
}