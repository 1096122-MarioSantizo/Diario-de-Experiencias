﻿namespace ProyectoClash
{
    partial class Mazos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txtVidaSeis = new System.Windows.Forms.TextBox();
            this.txtDañoSeis = new System.Windows.Forms.TextBox();
            this.lblBalance = new System.Windows.Forms.Label();
            this.lblDefensa = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblMonta = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lblTronco = new System.Windows.Forms.Label();
            this.lblMosquetera = new System.Windows.Forms.Label();
            this.lblEspiritu = new System.Windows.Forms.Label();
            this.lblGolem = new System.Windows.Forms.Label();
            this.lblBola = new System.Windows.Forms.Label();
            this.lblCañon = new System.Windows.Forms.Label();
            this.lblEsqueleto = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lblBalanceSube = new System.Windows.Forms.Label();
            this.lblDefensaSube = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.lblGigante = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.lblEsque = new System.Windows.Forms.Label();
            this.lblTron = new System.Windows.Forms.Label();
            this.lblBandida = new System.Windows.Forms.Label();
            this.lblEsbirros = new System.Windows.Forms.Label();
            this.lblBaby = new System.Windows.Forms.Label();
            this.lblMago = new System.Windows.Forms.Label();
            this.lblRayo = new System.Windows.Forms.Label();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.label44 = new System.Windows.Forms.Label();
            this.lblVidaSube = new System.Windows.Forms.Label();
            this.lblDañoSube = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.lblBalanceMinero = new System.Windows.Forms.Label();
            this.lblDefensaMinero = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.lblTorre = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.lblArquero = new System.Windows.Forms.Label();
            this.lblMinero = new System.Windows.Forms.Label();
            this.lblDuendes = new System.Windows.Forms.Label();
            this.lbltroncus = new System.Windows.Forms.Label();
            this.lblTornado = new System.Windows.Forms.Label();
            this.lblValquiria = new System.Windows.Forms.Label();
            this.lblRompe = new System.Windows.Forms.Label();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.label61 = new System.Windows.Forms.Label();
            this.lblVidaMinero = new System.Windows.Forms.Label();
            this.lblDañoMinero = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.lblBalanceLava = new System.Windows.Forms.Label();
            this.lblDefensaLava = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.lblMurcielago = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.lblSabueso = new System.Windows.Forms.Label();
            this.lblPrincesa = new System.Windows.Forms.Label();
            this.lblGlobo = new System.Windows.Forms.Label();
            this.lblMini = new System.Windows.Forms.Label();
            this.lblVeneno = new System.Windows.Forms.Label();
            this.lblMega = new System.Windows.Forms.Label();
            this.lblLanzad = new System.Windows.Forms.Label();
            this.pictureBox26 = new System.Windows.Forms.PictureBox();
            this.pictureBox27 = new System.Windows.Forms.PictureBox();
            this.pictureBox28 = new System.Windows.Forms.PictureBox();
            this.pictureBox29 = new System.Windows.Forms.PictureBox();
            this.pictureBox30 = new System.Windows.Forms.PictureBox();
            this.pictureBox31 = new System.Windows.Forms.PictureBox();
            this.pictureBox32 = new System.Windows.Forms.PictureBox();
            this.label90 = new System.Windows.Forms.Label();
            this.lblVidaLava = new System.Windows.Forms.Label();
            this.lblDañoLava = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.btnPvP = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(362, 165);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "Propiedades:";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(590, 458);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(138, 66);
            this.button1.TabIndex = 1;
            this.button1.Text = "Ver Mazos";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.SlateBlue;
            this.groupBox1.Controls.Add(this.tabControl1);
            this.groupBox1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(6, 18);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(585, 935);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Jugador 1 - Mazos";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(0, 43);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(585, 883);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Firebrick;
            this.tabPage1.Controls.Add(this.txtVidaSeis);
            this.tabPage1.Controls.Add(this.txtDañoSeis);
            this.tabPage1.Controls.Add(this.lblBalance);
            this.tabPage1.Controls.Add(this.lblDefensa);
            this.tabPage1.Controls.Add(this.label18);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.tableLayoutPanel1);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 35);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage1.Size = new System.Drawing.Size(577, 844);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Dos con seis";
            // 
            // txtVidaSeis
            // 
            this.txtVidaSeis.BackColor = System.Drawing.Color.Firebrick;
            this.txtVidaSeis.Location = new System.Drawing.Point(366, 280);
            this.txtVidaSeis.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtVidaSeis.Name = "txtVidaSeis";
            this.txtVidaSeis.Size = new System.Drawing.Size(148, 30);
            this.txtVidaSeis.TabIndex = 7;
            this.txtVidaSeis.Text = "|";
            // 
            // txtDañoSeis
            // 
            this.txtDañoSeis.BackColor = System.Drawing.Color.Firebrick;
            this.txtDañoSeis.Location = new System.Drawing.Point(368, 222);
            this.txtDañoSeis.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtDañoSeis.Name = "txtDañoSeis";
            this.txtDañoSeis.Size = new System.Drawing.Size(148, 30);
            this.txtDañoSeis.TabIndex = 6;
            this.txtDañoSeis.Text = "|";
            // 
            // lblBalance
            // 
            this.lblBalance.AutoSize = true;
            this.lblBalance.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBalance.Location = new System.Drawing.Point(370, 500);
            this.lblBalance.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBalance.Name = "lblBalance";
            this.lblBalance.Size = new System.Drawing.Size(24, 26);
            this.lblBalance.TabIndex = 5;
            this.lblBalance.Text = "|";
            // 
            // lblDefensa
            // 
            this.lblDefensa.AutoSize = true;
            this.lblDefensa.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDefensa.Location = new System.Drawing.Point(368, 338);
            this.lblDefensa.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDefensa.Name = "lblDefensa";
            this.lblDefensa.Size = new System.Drawing.Size(24, 26);
            this.lblDefensa.TabIndex = 5;
            this.lblDefensa.Text = "|";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label18.Location = new System.Drawing.Point(366, 474);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(90, 26);
            this.label18.TabIndex = 4;
            this.label18.Text = "Balance:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label17.Location = new System.Drawing.Point(366, 312);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(90, 26);
            this.label17.TabIndex = 4;
            this.label17.Text = "Defensa:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label16.Location = new System.Drawing.Point(360, 252);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(152, 26);
            this.label16.TabIndex = 3;
            this.label16.Text = "Puntos de vida:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.Location = new System.Drawing.Point(366, 195);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 26);
            this.label9.TabIndex = 3;
            this.label9.Text = "Daño:";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label5, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label6, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox1, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label8, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblMonta, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label10, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label11, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label12, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label13, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.label14, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.label15, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.lblTronco, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblMosquetera, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblEspiritu, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.lblGolem, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.lblBola, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.lblCañon, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.lblEsqueleto, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox3, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox4, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox2, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox5, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox6, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox7, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox8, 2, 7);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(14, 42);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 9;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(350, 729);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(5, 1);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 26);
            this.label4.TabIndex = 0;
            this.label4.Text = "No.";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(57, 1);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(189, 26);
            this.label5.TabIndex = 1;
            this.label5.Text = "Nombre";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Location = new System.Drawing.Point(255, 1);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 26);
            this.label6.TabIndex = 2;
            this.label6.Text = "Foto";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ProyectoClash.Properties.Resources.montapuercos;
            this.pictureBox1.Location = new System.Drawing.Point(255, 33);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(90, 77);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Location = new System.Drawing.Point(5, 28);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 87);
            this.label7.TabIndex = 4;
            this.label7.Text = "1";
            this.label7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Location = new System.Drawing.Point(5, 116);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 87);
            this.label8.TabIndex = 5;
            this.label8.Text = "2";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblMonta
            // 
            this.lblMonta.AutoSize = true;
            this.lblMonta.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMonta.Location = new System.Drawing.Point(57, 28);
            this.lblMonta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMonta.Name = "lblMonta";
            this.lblMonta.Size = new System.Drawing.Size(189, 87);
            this.lblMonta.TabIndex = 6;
            this.lblMonta.Text = "|";
            this.lblMonta.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Location = new System.Drawing.Point(5, 204);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(43, 87);
            this.label10.TabIndex = 7;
            this.label10.Text = "3";
            this.label10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Location = new System.Drawing.Point(5, 292);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(43, 87);
            this.label11.TabIndex = 8;
            this.label11.Text = "4";
            this.label11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Location = new System.Drawing.Point(5, 380);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(43, 87);
            this.label12.TabIndex = 8;
            this.label12.Text = "5";
            this.label12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Location = new System.Drawing.Point(5, 468);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(43, 87);
            this.label13.TabIndex = 8;
            this.label13.Text = "6";
            this.label13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Location = new System.Drawing.Point(5, 556);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(43, 87);
            this.label14.TabIndex = 8;
            this.label14.Text = "7";
            this.label14.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Location = new System.Drawing.Point(5, 644);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(43, 84);
            this.label15.TabIndex = 8;
            this.label15.Text = "8";
            this.label15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblTronco
            // 
            this.lblTronco.AutoSize = true;
            this.lblTronco.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTronco.Location = new System.Drawing.Point(57, 116);
            this.lblTronco.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTronco.Name = "lblTronco";
            this.lblTronco.Size = new System.Drawing.Size(189, 87);
            this.lblTronco.TabIndex = 9;
            this.lblTronco.Text = "|";
            this.lblTronco.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMosquetera
            // 
            this.lblMosquetera.AutoSize = true;
            this.lblMosquetera.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMosquetera.Location = new System.Drawing.Point(57, 204);
            this.lblMosquetera.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMosquetera.Name = "lblMosquetera";
            this.lblMosquetera.Size = new System.Drawing.Size(189, 87);
            this.lblMosquetera.TabIndex = 9;
            this.lblMosquetera.Text = "|";
            this.lblMosquetera.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblEspiritu
            // 
            this.lblEspiritu.AutoSize = true;
            this.lblEspiritu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEspiritu.Location = new System.Drawing.Point(57, 292);
            this.lblEspiritu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEspiritu.Name = "lblEspiritu";
            this.lblEspiritu.Size = new System.Drawing.Size(189, 87);
            this.lblEspiritu.TabIndex = 9;
            this.lblEspiritu.Text = "|";
            this.lblEspiritu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGolem
            // 
            this.lblGolem.AutoSize = true;
            this.lblGolem.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblGolem.Location = new System.Drawing.Point(57, 380);
            this.lblGolem.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGolem.Name = "lblGolem";
            this.lblGolem.Size = new System.Drawing.Size(189, 87);
            this.lblGolem.TabIndex = 9;
            this.lblGolem.Text = "|";
            this.lblGolem.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBola
            // 
            this.lblBola.AutoSize = true;
            this.lblBola.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblBola.Location = new System.Drawing.Point(57, 468);
            this.lblBola.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBola.Name = "lblBola";
            this.lblBola.Size = new System.Drawing.Size(189, 87);
            this.lblBola.TabIndex = 9;
            this.lblBola.Text = "|";
            this.lblBola.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCañon
            // 
            this.lblCañon.AutoSize = true;
            this.lblCañon.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCañon.Location = new System.Drawing.Point(57, 556);
            this.lblCañon.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCañon.Name = "lblCañon";
            this.lblCañon.Size = new System.Drawing.Size(189, 87);
            this.lblCañon.TabIndex = 9;
            this.lblCañon.Text = "|";
            this.lblCañon.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblEsqueleto
            // 
            this.lblEsqueleto.AutoSize = true;
            this.lblEsqueleto.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEsqueleto.Location = new System.Drawing.Point(57, 644);
            this.lblEsqueleto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEsqueleto.Name = "lblEsqueleto";
            this.lblEsqueleto.Size = new System.Drawing.Size(189, 84);
            this.lblEsqueleto.TabIndex = 9;
            this.lblEsqueleto.Text = "|";
            this.lblEsqueleto.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::ProyectoClash.Properties.Resources.mosquetera;
            this.pictureBox3.Location = new System.Drawing.Point(255, 209);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(90, 77);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 11;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Visible = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::ProyectoClash.Properties.Resources.espirituhielo;
            this.pictureBox4.Location = new System.Drawing.Point(255, 297);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(90, 77);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 12;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Visible = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::ProyectoClash.Properties.Resources.tronco1;
            this.pictureBox2.Location = new System.Drawing.Point(255, 121);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(90, 77);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Visible = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::ProyectoClash.Properties.Resources.golemhielo;
            this.pictureBox5.Location = new System.Drawing.Point(255, 385);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(90, 77);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 13;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Visible = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::ProyectoClash.Properties.Resources.esqueletos;
            this.pictureBox6.Location = new System.Drawing.Point(255, 649);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(90, 74);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 14;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Visible = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::ProyectoClash.Properties.Resources.bolafuego;
            this.pictureBox7.Location = new System.Drawing.Point(255, 473);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(90, 77);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 15;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Visible = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::ProyectoClash.Properties.Resources.cañon;
            this.pictureBox8.Location = new System.Drawing.Point(255, 561);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(90, 77);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 16;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 9);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(166, 26);
            this.label3.TabIndex = 0;
            this.label3.Text = "Cartas a utilizar:";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Firebrick;
            this.tabPage2.Controls.Add(this.lblBalanceSube);
            this.tabPage2.Controls.Add(this.lblDefensaSube);
            this.tabPage2.Controls.Add(this.label21);
            this.tabPage2.Controls.Add(this.label22);
            this.tabPage2.Controls.Add(this.label23);
            this.tabPage2.Controls.Add(this.label24);
            this.tabPage2.Controls.Add(this.tableLayoutPanel2);
            this.tabPage2.Controls.Add(this.label44);
            this.tabPage2.Controls.Add(this.lblVidaSube);
            this.tabPage2.Controls.Add(this.lblDañoSube);
            this.tabPage2.Controls.Add(this.label47);
            this.tabPage2.Location = new System.Drawing.Point(4, 35);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage2.Size = new System.Drawing.Size(577, 844);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Sube Copas";
            // 
            // lblBalanceSube
            // 
            this.lblBalanceSube.AutoSize = true;
            this.lblBalanceSube.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBalanceSube.Location = new System.Drawing.Point(366, 508);
            this.lblBalanceSube.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBalanceSube.Name = "lblBalanceSube";
            this.lblBalanceSube.Size = new System.Drawing.Size(24, 26);
            this.lblBalanceSube.TabIndex = 15;
            this.lblBalanceSube.Text = "|";
            // 
            // lblDefensaSube
            // 
            this.lblDefensaSube.AutoSize = true;
            this.lblDefensaSube.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDefensaSube.Location = new System.Drawing.Point(363, 348);
            this.lblDefensaSube.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDefensaSube.Name = "lblDefensaSube";
            this.lblDefensaSube.Size = new System.Drawing.Size(24, 26);
            this.lblDefensaSube.TabIndex = 16;
            this.lblDefensaSube.Text = "|";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label21.Location = new System.Drawing.Point(362, 482);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(90, 26);
            this.label21.TabIndex = 13;
            this.label21.Text = "Balance:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label22.Location = new System.Drawing.Point(362, 322);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(90, 26);
            this.label22.TabIndex = 14;
            this.label22.Text = "Defensa:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label23.Location = new System.Drawing.Point(356, 262);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(152, 26);
            this.label23.TabIndex = 11;
            this.label23.Text = "Puntos de vida:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label24.Location = new System.Drawing.Point(362, 203);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(64, 26);
            this.label24.TabIndex = 12;
            this.label24.Text = "Daño:";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.Controls.Add(this.label25, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label26, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label27, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.pictureBox9, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.label28, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label29, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.lblGigante, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.label31, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.label32, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.label33, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.label34, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.label35, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.label36, 0, 8);
            this.tableLayoutPanel2.Controls.Add(this.lblEsque, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.lblTron, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.lblBandida, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.lblEsbirros, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.lblBaby, 1, 6);
            this.tableLayoutPanel2.Controls.Add(this.lblMago, 1, 7);
            this.tableLayoutPanel2.Controls.Add(this.lblRayo, 1, 8);
            this.tableLayoutPanel2.Controls.Add(this.pictureBox10, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.pictureBox11, 2, 4);
            this.tableLayoutPanel2.Controls.Add(this.pictureBox12, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.pictureBox13, 2, 5);
            this.tableLayoutPanel2.Controls.Add(this.pictureBox14, 2, 8);
            this.tableLayoutPanel2.Controls.Add(this.pictureBox15, 2, 6);
            this.tableLayoutPanel2.Controls.Add(this.pictureBox16, 2, 7);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(9, 49);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 9;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.Size = new System.Drawing.Size(350, 729);
            this.tableLayoutPanel2.TabIndex = 8;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label25.Location = new System.Drawing.Point(5, 1);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(43, 26);
            this.label25.TabIndex = 0;
            this.label25.Text = "No.";
            this.label25.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label26.Location = new System.Drawing.Point(57, 1);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(189, 26);
            this.label26.TabIndex = 1;
            this.label26.Text = "Nombre";
            this.label26.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label27.Location = new System.Drawing.Point(255, 1);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(90, 26);
            this.label27.TabIndex = 2;
            this.label27.Text = "Foto";
            this.label27.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::ProyectoClash.Properties.Resources.gigante;
            this.pictureBox9.Location = new System.Drawing.Point(255, 33);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(90, 77);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 3;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Visible = false;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label28.Location = new System.Drawing.Point(5, 28);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(43, 87);
            this.label28.TabIndex = 4;
            this.label28.Text = "1";
            this.label28.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label29.Location = new System.Drawing.Point(5, 116);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(43, 87);
            this.label29.TabIndex = 5;
            this.label29.Text = "2";
            this.label29.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblGigante
            // 
            this.lblGigante.AutoSize = true;
            this.lblGigante.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblGigante.Location = new System.Drawing.Point(57, 28);
            this.lblGigante.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGigante.Name = "lblGigante";
            this.lblGigante.Size = new System.Drawing.Size(189, 87);
            this.lblGigante.TabIndex = 6;
            this.lblGigante.Text = "|";
            this.lblGigante.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label31.Location = new System.Drawing.Point(5, 204);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(43, 87);
            this.label31.TabIndex = 7;
            this.label31.Text = "3";
            this.label31.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label32.Location = new System.Drawing.Point(5, 292);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(43, 87);
            this.label32.TabIndex = 8;
            this.label32.Text = "4";
            this.label32.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label33.Location = new System.Drawing.Point(5, 380);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(43, 87);
            this.label33.TabIndex = 8;
            this.label33.Text = "5";
            this.label33.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label34.Location = new System.Drawing.Point(5, 468);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(43, 87);
            this.label34.TabIndex = 8;
            this.label34.Text = "6";
            this.label34.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label35.Location = new System.Drawing.Point(5, 556);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(43, 87);
            this.label35.TabIndex = 8;
            this.label35.Text = "7";
            this.label35.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label36.Location = new System.Drawing.Point(5, 644);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(43, 84);
            this.label36.TabIndex = 8;
            this.label36.Text = "8";
            this.label36.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblEsque
            // 
            this.lblEsque.AutoSize = true;
            this.lblEsque.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEsque.Location = new System.Drawing.Point(57, 116);
            this.lblEsque.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEsque.Name = "lblEsque";
            this.lblEsque.Size = new System.Drawing.Size(189, 87);
            this.lblEsque.TabIndex = 9;
            this.lblEsque.Text = "|";
            this.lblEsque.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTron
            // 
            this.lblTron.AutoSize = true;
            this.lblTron.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTron.Location = new System.Drawing.Point(57, 204);
            this.lblTron.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTron.Name = "lblTron";
            this.lblTron.Size = new System.Drawing.Size(189, 87);
            this.lblTron.TabIndex = 9;
            this.lblTron.Text = "|";
            this.lblTron.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBandida
            // 
            this.lblBandida.AutoSize = true;
            this.lblBandida.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblBandida.Location = new System.Drawing.Point(57, 292);
            this.lblBandida.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBandida.Name = "lblBandida";
            this.lblBandida.Size = new System.Drawing.Size(189, 87);
            this.lblBandida.TabIndex = 9;
            this.lblBandida.Text = "|";
            this.lblBandida.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblEsbirros
            // 
            this.lblEsbirros.AutoSize = true;
            this.lblEsbirros.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblEsbirros.Location = new System.Drawing.Point(57, 380);
            this.lblEsbirros.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEsbirros.Name = "lblEsbirros";
            this.lblEsbirros.Size = new System.Drawing.Size(189, 87);
            this.lblEsbirros.TabIndex = 9;
            this.lblEsbirros.Text = "|";
            this.lblEsbirros.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBaby
            // 
            this.lblBaby.AutoSize = true;
            this.lblBaby.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblBaby.Location = new System.Drawing.Point(57, 468);
            this.lblBaby.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBaby.Name = "lblBaby";
            this.lblBaby.Size = new System.Drawing.Size(189, 87);
            this.lblBaby.TabIndex = 9;
            this.lblBaby.Text = "|";
            this.lblBaby.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMago
            // 
            this.lblMago.AutoSize = true;
            this.lblMago.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMago.Location = new System.Drawing.Point(57, 556);
            this.lblMago.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMago.Name = "lblMago";
            this.lblMago.Size = new System.Drawing.Size(189, 87);
            this.lblMago.TabIndex = 9;
            this.lblMago.Text = "|";
            this.lblMago.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblRayo
            // 
            this.lblRayo.AutoSize = true;
            this.lblRayo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRayo.Location = new System.Drawing.Point(57, 644);
            this.lblRayo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRayo.Name = "lblRayo";
            this.lblRayo.Size = new System.Drawing.Size(189, 84);
            this.lblRayo.TabIndex = 9;
            this.lblRayo.Text = "|";
            this.lblRayo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::ProyectoClash.Properties.Resources.tronco1;
            this.pictureBox10.Location = new System.Drawing.Point(255, 209);
            this.pictureBox10.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(90, 77);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 11;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Visible = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::ProyectoClash.Properties.Resources.bandida;
            this.pictureBox11.Location = new System.Drawing.Point(255, 297);
            this.pictureBox11.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(90, 77);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 12;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Visible = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::ProyectoClash.Properties.Resources.esqueletos1;
            this.pictureBox12.Location = new System.Drawing.Point(255, 121);
            this.pictureBox12.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(90, 77);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 10;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Visible = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::ProyectoClash.Properties.Resources.esbirros;
            this.pictureBox13.Location = new System.Drawing.Point(255, 385);
            this.pictureBox13.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(90, 77);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 13;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.Visible = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = global::ProyectoClash.Properties.Resources.rayo;
            this.pictureBox14.Location = new System.Drawing.Point(255, 649);
            this.pictureBox14.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(90, 74);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 14;
            this.pictureBox14.TabStop = false;
            this.pictureBox14.Visible = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = global::ProyectoClash.Properties.Resources.baby;
            this.pictureBox15.Location = new System.Drawing.Point(255, 473);
            this.pictureBox15.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(90, 77);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 15;
            this.pictureBox15.TabStop = false;
            this.pictureBox15.Visible = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = global::ProyectoClash.Properties.Resources.mago;
            this.pictureBox16.Location = new System.Drawing.Point(255, 561);
            this.pictureBox16.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(90, 77);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox16.TabIndex = 16;
            this.pictureBox16.TabStop = false;
            this.pictureBox16.Visible = false;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(4, 17);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(166, 26);
            this.label44.TabIndex = 6;
            this.label44.Text = "Cartas a utilizar:";
            // 
            // lblVidaSube
            // 
            this.lblVidaSube.AutoSize = true;
            this.lblVidaSube.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVidaSube.Location = new System.Drawing.Point(363, 286);
            this.lblVidaSube.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblVidaSube.Name = "lblVidaSube";
            this.lblVidaSube.Size = new System.Drawing.Size(24, 26);
            this.lblVidaSube.TabIndex = 9;
            this.lblVidaSube.Text = "|";
            // 
            // lblDañoSube
            // 
            this.lblDañoSube.AutoSize = true;
            this.lblDañoSube.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDañoSube.Location = new System.Drawing.Point(363, 226);
            this.lblDañoSube.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDañoSube.Name = "lblDañoSube";
            this.lblDañoSube.Size = new System.Drawing.Size(24, 26);
            this.lblDañoSube.TabIndex = 10;
            this.lblDañoSube.Text = "|";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label47.Location = new System.Drawing.Point(357, 172);
            this.label47.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(128, 26);
            this.label47.TabIndex = 7;
            this.label47.Text = "Propiedades:";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.SlateBlue;
            this.groupBox2.Controls.Add(this.tabControl2);
            this.groupBox2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(723, 18);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Size = new System.Drawing.Size(585, 935);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Jugador 2 - Mazos";
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Location = new System.Drawing.Point(3, 38);
            this.tabControl2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(576, 883);
            this.tabControl2.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Firebrick;
            this.tabPage3.Controls.Add(this.lblBalanceMinero);
            this.tabPage3.Controls.Add(this.lblDefensaMinero);
            this.tabPage3.Controls.Add(this.label30);
            this.tabPage3.Controls.Add(this.label37);
            this.tabPage3.Controls.Add(this.label38);
            this.tabPage3.Controls.Add(this.label39);
            this.tabPage3.Controls.Add(this.tableLayoutPanel3);
            this.tabPage3.Controls.Add(this.label61);
            this.tabPage3.Controls.Add(this.lblVidaMinero);
            this.tabPage3.Controls.Add(this.lblDañoMinero);
            this.tabPage3.Controls.Add(this.label64);
            this.tabPage3.Location = new System.Drawing.Point(4, 35);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage3.Size = new System.Drawing.Size(568, 844);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "MinerControl";
            // 
            // lblBalanceMinero
            // 
            this.lblBalanceMinero.AutoSize = true;
            this.lblBalanceMinero.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBalanceMinero.Location = new System.Drawing.Point(366, 523);
            this.lblBalanceMinero.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBalanceMinero.Name = "lblBalanceMinero";
            this.lblBalanceMinero.Size = new System.Drawing.Size(24, 26);
            this.lblBalanceMinero.TabIndex = 26;
            this.lblBalanceMinero.Text = "|";
            // 
            // lblDefensaMinero
            // 
            this.lblDefensaMinero.AutoSize = true;
            this.lblDefensaMinero.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDefensaMinero.Location = new System.Drawing.Point(363, 334);
            this.lblDefensaMinero.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDefensaMinero.Name = "lblDefensaMinero";
            this.lblDefensaMinero.Size = new System.Drawing.Size(24, 26);
            this.lblDefensaMinero.TabIndex = 27;
            this.lblDefensaMinero.Text = "|";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label30.Location = new System.Drawing.Point(362, 497);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(90, 26);
            this.label30.TabIndex = 24;
            this.label30.Text = "Balance:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label37.Location = new System.Drawing.Point(362, 308);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(90, 26);
            this.label37.TabIndex = 25;
            this.label37.Text = "Defensa:";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label38.Location = new System.Drawing.Point(356, 249);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(152, 26);
            this.label38.TabIndex = 22;
            this.label38.Text = "Puntos de vida:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label39.Location = new System.Drawing.Point(362, 194);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(64, 26);
            this.label39.TabIndex = 23;
            this.label39.Text = "Daño:";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.Controls.Add(this.label40, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label41, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label42, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox17, 2, 1);
            this.tableLayoutPanel3.Controls.Add(this.label43, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label45, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.lblTorre, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.label48, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.label49, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.label50, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.label51, 0, 6);
            this.tableLayoutPanel3.Controls.Add(this.label52, 0, 7);
            this.tableLayoutPanel3.Controls.Add(this.label53, 0, 8);
            this.tableLayoutPanel3.Controls.Add(this.lblArquero, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.lblMinero, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.lblDuendes, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.lbltroncus, 1, 5);
            this.tableLayoutPanel3.Controls.Add(this.lblTornado, 1, 6);
            this.tableLayoutPanel3.Controls.Add(this.lblValquiria, 1, 7);
            this.tableLayoutPanel3.Controls.Add(this.lblRompe, 1, 8);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox18, 2, 3);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox19, 2, 4);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox20, 2, 2);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox21, 2, 5);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox22, 2, 8);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox23, 2, 6);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox24, 2, 7);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(9, 40);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 9;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.Size = new System.Drawing.Size(350, 729);
            this.tableLayoutPanel3.TabIndex = 19;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label40.Location = new System.Drawing.Point(5, 1);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(43, 26);
            this.label40.TabIndex = 0;
            this.label40.Text = "No.";
            this.label40.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label41.Location = new System.Drawing.Point(57, 1);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(189, 26);
            this.label41.TabIndex = 1;
            this.label41.Text = "Nombre";
            this.label41.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label42.Location = new System.Drawing.Point(255, 1);
            this.label42.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(90, 26);
            this.label42.TabIndex = 2;
            this.label42.Text = "Foto";
            this.label42.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pictureBox17
            // 
            this.pictureBox17.Image = global::ProyectoClash.Properties.Resources.bombardera;
            this.pictureBox17.Location = new System.Drawing.Point(255, 33);
            this.pictureBox17.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(90, 77);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox17.TabIndex = 3;
            this.pictureBox17.TabStop = false;
            this.pictureBox17.Visible = false;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label43.Location = new System.Drawing.Point(5, 28);
            this.label43.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(43, 87);
            this.label43.TabIndex = 4;
            this.label43.Text = "1";
            this.label43.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label45.Location = new System.Drawing.Point(5, 116);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(43, 87);
            this.label45.TabIndex = 5;
            this.label45.Text = "2";
            this.label45.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblTorre
            // 
            this.lblTorre.AutoSize = true;
            this.lblTorre.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTorre.Location = new System.Drawing.Point(57, 28);
            this.lblTorre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTorre.Name = "lblTorre";
            this.lblTorre.Size = new System.Drawing.Size(189, 87);
            this.lblTorre.TabIndex = 6;
            this.lblTorre.Text = "|";
            this.lblTorre.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label48.Location = new System.Drawing.Point(5, 204);
            this.label48.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(43, 87);
            this.label48.TabIndex = 7;
            this.label48.Text = "3";
            this.label48.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label49.Location = new System.Drawing.Point(5, 292);
            this.label49.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(43, 87);
            this.label49.TabIndex = 8;
            this.label49.Text = "4";
            this.label49.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label50.Location = new System.Drawing.Point(5, 380);
            this.label50.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(43, 87);
            this.label50.TabIndex = 8;
            this.label50.Text = "5";
            this.label50.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label51.Location = new System.Drawing.Point(5, 468);
            this.label51.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(43, 87);
            this.label51.TabIndex = 8;
            this.label51.Text = "6";
            this.label51.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label52.Location = new System.Drawing.Point(5, 556);
            this.label52.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(43, 87);
            this.label52.TabIndex = 8;
            this.label52.Text = "7";
            this.label52.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label53.Location = new System.Drawing.Point(5, 644);
            this.label53.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(43, 84);
            this.label53.TabIndex = 8;
            this.label53.Text = "8";
            this.label53.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblArquero
            // 
            this.lblArquero.AutoSize = true;
            this.lblArquero.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblArquero.Location = new System.Drawing.Point(57, 116);
            this.lblArquero.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblArquero.Name = "lblArquero";
            this.lblArquero.Size = new System.Drawing.Size(189, 87);
            this.lblArquero.TabIndex = 9;
            this.lblArquero.Text = "|";
            this.lblArquero.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMinero
            // 
            this.lblMinero.AutoSize = true;
            this.lblMinero.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMinero.Location = new System.Drawing.Point(57, 204);
            this.lblMinero.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMinero.Name = "lblMinero";
            this.lblMinero.Size = new System.Drawing.Size(189, 87);
            this.lblMinero.TabIndex = 9;
            this.lblMinero.Text = "|";
            this.lblMinero.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDuendes
            // 
            this.lblDuendes.AutoSize = true;
            this.lblDuendes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDuendes.Location = new System.Drawing.Point(57, 292);
            this.lblDuendes.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDuendes.Name = "lblDuendes";
            this.lblDuendes.Size = new System.Drawing.Size(189, 87);
            this.lblDuendes.TabIndex = 9;
            this.lblDuendes.Text = "|";
            this.lblDuendes.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbltroncus
            // 
            this.lbltroncus.AutoSize = true;
            this.lbltroncus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbltroncus.Location = new System.Drawing.Point(57, 380);
            this.lbltroncus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbltroncus.Name = "lbltroncus";
            this.lbltroncus.Size = new System.Drawing.Size(189, 87);
            this.lbltroncus.TabIndex = 9;
            this.lbltroncus.Text = "|";
            this.lbltroncus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTornado
            // 
            this.lblTornado.AutoSize = true;
            this.lblTornado.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTornado.Location = new System.Drawing.Point(57, 468);
            this.lblTornado.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTornado.Name = "lblTornado";
            this.lblTornado.Size = new System.Drawing.Size(189, 87);
            this.lblTornado.TabIndex = 9;
            this.lblTornado.Text = "|";
            this.lblTornado.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblValquiria
            // 
            this.lblValquiria.AutoSize = true;
            this.lblValquiria.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblValquiria.Location = new System.Drawing.Point(57, 556);
            this.lblValquiria.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblValquiria.Name = "lblValquiria";
            this.lblValquiria.Size = new System.Drawing.Size(189, 87);
            this.lblValquiria.TabIndex = 9;
            this.lblValquiria.Text = "|";
            this.lblValquiria.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblRompe
            // 
            this.lblRompe.AutoSize = true;
            this.lblRompe.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRompe.Location = new System.Drawing.Point(57, 644);
            this.lblRompe.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRompe.Name = "lblRompe";
            this.lblRompe.Size = new System.Drawing.Size(189, 84);
            this.lblRompe.TabIndex = 9;
            this.lblRompe.Text = "|";
            this.lblRompe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox18
            // 
            this.pictureBox18.Image = global::ProyectoClash.Properties.Resources.minero;
            this.pictureBox18.Location = new System.Drawing.Point(255, 209);
            this.pictureBox18.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(90, 77);
            this.pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox18.TabIndex = 11;
            this.pictureBox18.TabStop = false;
            this.pictureBox18.Visible = false;
            // 
            // pictureBox19
            // 
            this.pictureBox19.Image = global::ProyectoClash.Properties.Resources.duendesl;
            this.pictureBox19.Location = new System.Drawing.Point(255, 297);
            this.pictureBox19.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(90, 77);
            this.pictureBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox19.TabIndex = 12;
            this.pictureBox19.TabStop = false;
            this.pictureBox19.Visible = false;
            // 
            // pictureBox20
            // 
            this.pictureBox20.Image = global::ProyectoClash.Properties.Resources.arquero;
            this.pictureBox20.Location = new System.Drawing.Point(255, 121);
            this.pictureBox20.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(90, 77);
            this.pictureBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox20.TabIndex = 10;
            this.pictureBox20.TabStop = false;
            this.pictureBox20.Visible = false;
            // 
            // pictureBox21
            // 
            this.pictureBox21.Image = global::ProyectoClash.Properties.Resources.tronco1;
            this.pictureBox21.Location = new System.Drawing.Point(255, 385);
            this.pictureBox21.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(90, 77);
            this.pictureBox21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox21.TabIndex = 13;
            this.pictureBox21.TabStop = false;
            this.pictureBox21.Visible = false;
            // 
            // pictureBox22
            // 
            this.pictureBox22.Image = global::ProyectoClash.Properties.Resources.rompemuros;
            this.pictureBox22.Location = new System.Drawing.Point(255, 649);
            this.pictureBox22.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(90, 74);
            this.pictureBox22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox22.TabIndex = 14;
            this.pictureBox22.TabStop = false;
            this.pictureBox22.Visible = false;
            // 
            // pictureBox23
            // 
            this.pictureBox23.Image = global::ProyectoClash.Properties.Resources.tornado;
            this.pictureBox23.Location = new System.Drawing.Point(255, 473);
            this.pictureBox23.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(90, 77);
            this.pictureBox23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox23.TabIndex = 15;
            this.pictureBox23.TabStop = false;
            this.pictureBox23.Visible = false;
            // 
            // pictureBox24
            // 
            this.pictureBox24.Image = global::ProyectoClash.Properties.Resources.valquiria;
            this.pictureBox24.Location = new System.Drawing.Point(255, 561);
            this.pictureBox24.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(90, 77);
            this.pictureBox24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox24.TabIndex = 16;
            this.pictureBox24.TabStop = false;
            this.pictureBox24.Visible = false;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(4, 8);
            this.label61.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(166, 26);
            this.label61.TabIndex = 17;
            this.label61.Text = "Cartas a utilizar:";
            // 
            // lblVidaMinero
            // 
            this.lblVidaMinero.AutoSize = true;
            this.lblVidaMinero.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVidaMinero.Location = new System.Drawing.Point(362, 272);
            this.lblVidaMinero.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblVidaMinero.Name = "lblVidaMinero";
            this.lblVidaMinero.Size = new System.Drawing.Size(24, 26);
            this.lblVidaMinero.TabIndex = 20;
            this.lblVidaMinero.Text = "|";
            // 
            // lblDañoMinero
            // 
            this.lblDañoMinero.AutoSize = true;
            this.lblDañoMinero.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDañoMinero.Location = new System.Drawing.Point(362, 218);
            this.lblDañoMinero.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDañoMinero.Name = "lblDañoMinero";
            this.lblDañoMinero.Size = new System.Drawing.Size(24, 26);
            this.lblDañoMinero.TabIndex = 21;
            this.lblDañoMinero.Text = "|";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label64.Location = new System.Drawing.Point(357, 163);
            this.label64.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(128, 26);
            this.label64.TabIndex = 18;
            this.label64.Text = "Propiedades:";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.Firebrick;
            this.tabPage4.Controls.Add(this.lblBalanceLava);
            this.tabPage4.Controls.Add(this.lblDefensaLava);
            this.tabPage4.Controls.Add(this.label67);
            this.tabPage4.Controls.Add(this.label68);
            this.tabPage4.Controls.Add(this.label69);
            this.tabPage4.Controls.Add(this.label70);
            this.tabPage4.Controls.Add(this.tableLayoutPanel4);
            this.tabPage4.Controls.Add(this.label90);
            this.tabPage4.Controls.Add(this.lblVidaLava);
            this.tabPage4.Controls.Add(this.lblDañoLava);
            this.tabPage4.Controls.Add(this.label93);
            this.tabPage4.Location = new System.Drawing.Point(4, 35);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage4.Size = new System.Drawing.Size(568, 844);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "LavaLoon";
            this.tabPage4.Click += new System.EventHandler(this.tabPage4_Click);
            // 
            // lblBalanceLava
            // 
            this.lblBalanceLava.AutoSize = true;
            this.lblBalanceLava.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBalanceLava.Location = new System.Drawing.Point(366, 535);
            this.lblBalanceLava.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBalanceLava.Name = "lblBalanceLava";
            this.lblBalanceLava.Size = new System.Drawing.Size(24, 26);
            this.lblBalanceLava.TabIndex = 26;
            this.lblBalanceLava.Text = "|";
            // 
            // lblDefensaLava
            // 
            this.lblDefensaLava.AutoSize = true;
            this.lblDefensaLava.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDefensaLava.Location = new System.Drawing.Point(363, 334);
            this.lblDefensaLava.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDefensaLava.Name = "lblDefensaLava";
            this.lblDefensaLava.Size = new System.Drawing.Size(24, 26);
            this.lblDefensaLava.TabIndex = 27;
            this.lblDefensaLava.Text = "|";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label67.Location = new System.Drawing.Point(362, 509);
            this.label67.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(90, 26);
            this.label67.TabIndex = 24;
            this.label67.Text = "Balance:";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label68.Location = new System.Drawing.Point(362, 308);
            this.label68.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(90, 26);
            this.label68.TabIndex = 25;
            this.label68.Text = "Defensa:";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label69.Location = new System.Drawing.Point(356, 249);
            this.label69.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(152, 26);
            this.label69.TabIndex = 22;
            this.label69.Text = "Puntos de vida:";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label70.Location = new System.Drawing.Point(362, 194);
            this.label70.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(64, 26);
            this.label70.TabIndex = 23;
            this.label70.Text = "Daño:";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel4.ColumnCount = 3;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.Controls.Add(this.label71, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.label72, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.label73, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.pictureBox25, 2, 1);
            this.tableLayoutPanel4.Controls.Add(this.label74, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.label75, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.lblMurcielago, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.label77, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.label78, 0, 4);
            this.tableLayoutPanel4.Controls.Add(this.label79, 0, 5);
            this.tableLayoutPanel4.Controls.Add(this.label80, 0, 6);
            this.tableLayoutPanel4.Controls.Add(this.label81, 0, 7);
            this.tableLayoutPanel4.Controls.Add(this.label82, 0, 8);
            this.tableLayoutPanel4.Controls.Add(this.lblSabueso, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.lblPrincesa, 1, 3);
            this.tableLayoutPanel4.Controls.Add(this.lblGlobo, 1, 4);
            this.tableLayoutPanel4.Controls.Add(this.lblMini, 1, 5);
            this.tableLayoutPanel4.Controls.Add(this.lblVeneno, 1, 6);
            this.tableLayoutPanel4.Controls.Add(this.lblMega, 1, 7);
            this.tableLayoutPanel4.Controls.Add(this.lblLanzad, 1, 8);
            this.tableLayoutPanel4.Controls.Add(this.pictureBox26, 2, 3);
            this.tableLayoutPanel4.Controls.Add(this.pictureBox27, 2, 4);
            this.tableLayoutPanel4.Controls.Add(this.pictureBox28, 2, 2);
            this.tableLayoutPanel4.Controls.Add(this.pictureBox29, 2, 5);
            this.tableLayoutPanel4.Controls.Add(this.pictureBox30, 2, 8);
            this.tableLayoutPanel4.Controls.Add(this.pictureBox31, 2, 6);
            this.tableLayoutPanel4.Controls.Add(this.pictureBox32, 2, 7);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(9, 40);
            this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 9;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.Size = new System.Drawing.Size(350, 729);
            this.tableLayoutPanel4.TabIndex = 19;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label71.Location = new System.Drawing.Point(5, 1);
            this.label71.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(43, 26);
            this.label71.TabIndex = 0;
            this.label71.Text = "No.";
            this.label71.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label72.Location = new System.Drawing.Point(57, 1);
            this.label72.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(189, 26);
            this.label72.TabIndex = 1;
            this.label72.Text = "Nombre";
            this.label72.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label73.Location = new System.Drawing.Point(255, 1);
            this.label73.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(90, 26);
            this.label73.TabIndex = 2;
            this.label73.Text = "Foto";
            this.label73.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pictureBox25
            // 
            this.pictureBox25.Image = global::ProyectoClash.Properties.Resources.murcielagos;
            this.pictureBox25.Location = new System.Drawing.Point(255, 33);
            this.pictureBox25.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(90, 77);
            this.pictureBox25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox25.TabIndex = 3;
            this.pictureBox25.TabStop = false;
            this.pictureBox25.Visible = false;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label74.Location = new System.Drawing.Point(5, 28);
            this.label74.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(43, 87);
            this.label74.TabIndex = 4;
            this.label74.Text = "1";
            this.label74.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label75.Location = new System.Drawing.Point(5, 116);
            this.label75.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(43, 87);
            this.label75.TabIndex = 5;
            this.label75.Text = "2";
            this.label75.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblMurcielago
            // 
            this.lblMurcielago.AutoSize = true;
            this.lblMurcielago.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMurcielago.Location = new System.Drawing.Point(57, 28);
            this.lblMurcielago.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMurcielago.Name = "lblMurcielago";
            this.lblMurcielago.Size = new System.Drawing.Size(189, 87);
            this.lblMurcielago.TabIndex = 6;
            this.lblMurcielago.Text = "|";
            this.lblMurcielago.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label77.Location = new System.Drawing.Point(5, 204);
            this.label77.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(43, 87);
            this.label77.TabIndex = 7;
            this.label77.Text = "3";
            this.label77.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label78.Location = new System.Drawing.Point(5, 292);
            this.label78.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(43, 87);
            this.label78.TabIndex = 8;
            this.label78.Text = "4";
            this.label78.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label79.Location = new System.Drawing.Point(5, 380);
            this.label79.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(43, 87);
            this.label79.TabIndex = 8;
            this.label79.Text = "5";
            this.label79.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label80.Location = new System.Drawing.Point(5, 468);
            this.label80.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(43, 87);
            this.label80.TabIndex = 8;
            this.label80.Text = "6";
            this.label80.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label81.Location = new System.Drawing.Point(5, 556);
            this.label81.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(43, 87);
            this.label81.TabIndex = 8;
            this.label81.Text = "7";
            this.label81.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label82.Location = new System.Drawing.Point(5, 644);
            this.label82.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(43, 84);
            this.label82.TabIndex = 8;
            this.label82.Text = "8";
            this.label82.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblSabueso
            // 
            this.lblSabueso.AutoSize = true;
            this.lblSabueso.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSabueso.Location = new System.Drawing.Point(57, 116);
            this.lblSabueso.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSabueso.Name = "lblSabueso";
            this.lblSabueso.Size = new System.Drawing.Size(189, 87);
            this.lblSabueso.TabIndex = 9;
            this.lblSabueso.Text = "|";
            this.lblSabueso.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPrincesa
            // 
            this.lblPrincesa.AutoSize = true;
            this.lblPrincesa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPrincesa.Location = new System.Drawing.Point(57, 204);
            this.lblPrincesa.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPrincesa.Name = "lblPrincesa";
            this.lblPrincesa.Size = new System.Drawing.Size(189, 87);
            this.lblPrincesa.TabIndex = 9;
            this.lblPrincesa.Text = "|";
            this.lblPrincesa.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGlobo
            // 
            this.lblGlobo.AutoSize = true;
            this.lblGlobo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblGlobo.Location = new System.Drawing.Point(57, 292);
            this.lblGlobo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGlobo.Name = "lblGlobo";
            this.lblGlobo.Size = new System.Drawing.Size(189, 87);
            this.lblGlobo.TabIndex = 9;
            this.lblGlobo.Text = "|";
            this.lblGlobo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMini
            // 
            this.lblMini.AutoSize = true;
            this.lblMini.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMini.Location = new System.Drawing.Point(57, 380);
            this.lblMini.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMini.Name = "lblMini";
            this.lblMini.Size = new System.Drawing.Size(189, 87);
            this.lblMini.TabIndex = 9;
            this.lblMini.Text = "|";
            this.lblMini.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblVeneno
            // 
            this.lblVeneno.AutoSize = true;
            this.lblVeneno.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblVeneno.Location = new System.Drawing.Point(57, 468);
            this.lblVeneno.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblVeneno.Name = "lblVeneno";
            this.lblVeneno.Size = new System.Drawing.Size(189, 87);
            this.lblVeneno.TabIndex = 9;
            this.lblVeneno.Text = "|";
            this.lblVeneno.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMega
            // 
            this.lblMega.AutoSize = true;
            this.lblMega.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMega.Location = new System.Drawing.Point(57, 556);
            this.lblMega.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMega.Name = "lblMega";
            this.lblMega.Size = new System.Drawing.Size(189, 87);
            this.lblMega.TabIndex = 9;
            this.lblMega.Text = "|";
            this.lblMega.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLanzad
            // 
            this.lblLanzad.AutoSize = true;
            this.lblLanzad.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblLanzad.Location = new System.Drawing.Point(57, 644);
            this.lblLanzad.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLanzad.Name = "lblLanzad";
            this.lblLanzad.Size = new System.Drawing.Size(189, 84);
            this.lblLanzad.TabIndex = 9;
            this.lblLanzad.Text = "|";
            this.lblLanzad.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox26
            // 
            this.pictureBox26.Image = global::ProyectoClash.Properties.Resources.princesa;
            this.pictureBox26.Location = new System.Drawing.Point(255, 209);
            this.pictureBox26.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox26.Name = "pictureBox26";
            this.pictureBox26.Size = new System.Drawing.Size(90, 77);
            this.pictureBox26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox26.TabIndex = 11;
            this.pictureBox26.TabStop = false;
            this.pictureBox26.Visible = false;
            // 
            // pictureBox27
            // 
            this.pictureBox27.Image = global::ProyectoClash.Properties.Resources.globo;
            this.pictureBox27.Location = new System.Drawing.Point(255, 297);
            this.pictureBox27.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox27.Name = "pictureBox27";
            this.pictureBox27.Size = new System.Drawing.Size(90, 77);
            this.pictureBox27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox27.TabIndex = 12;
            this.pictureBox27.TabStop = false;
            this.pictureBox27.Visible = false;
            // 
            // pictureBox28
            // 
            this.pictureBox28.Image = global::ProyectoClash.Properties.Resources.sabueso;
            this.pictureBox28.Location = new System.Drawing.Point(255, 121);
            this.pictureBox28.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox28.Name = "pictureBox28";
            this.pictureBox28.Size = new System.Drawing.Size(90, 77);
            this.pictureBox28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox28.TabIndex = 10;
            this.pictureBox28.TabStop = false;
            this.pictureBox28.Visible = false;
            // 
            // pictureBox29
            // 
            this.pictureBox29.Image = global::ProyectoClash.Properties.Resources.minipeka;
            this.pictureBox29.Location = new System.Drawing.Point(255, 385);
            this.pictureBox29.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox29.Name = "pictureBox29";
            this.pictureBox29.Size = new System.Drawing.Size(90, 77);
            this.pictureBox29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox29.TabIndex = 13;
            this.pictureBox29.TabStop = false;
            this.pictureBox29.Visible = false;
            // 
            // pictureBox30
            // 
            this.pictureBox30.Image = global::ProyectoClash.Properties.Resources.lanzadardos;
            this.pictureBox30.Location = new System.Drawing.Point(255, 649);
            this.pictureBox30.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox30.Name = "pictureBox30";
            this.pictureBox30.Size = new System.Drawing.Size(90, 74);
            this.pictureBox30.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox30.TabIndex = 14;
            this.pictureBox30.TabStop = false;
            this.pictureBox30.Visible = false;
            // 
            // pictureBox31
            // 
            this.pictureBox31.Image = global::ProyectoClash.Properties.Resources.veneno;
            this.pictureBox31.Location = new System.Drawing.Point(255, 473);
            this.pictureBox31.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox31.Name = "pictureBox31";
            this.pictureBox31.Size = new System.Drawing.Size(90, 77);
            this.pictureBox31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox31.TabIndex = 15;
            this.pictureBox31.TabStop = false;
            this.pictureBox31.Visible = false;
            // 
            // pictureBox32
            // 
            this.pictureBox32.Image = global::ProyectoClash.Properties.Resources.megaesbirro;
            this.pictureBox32.Location = new System.Drawing.Point(255, 561);
            this.pictureBox32.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox32.Name = "pictureBox32";
            this.pictureBox32.Size = new System.Drawing.Size(90, 77);
            this.pictureBox32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox32.TabIndex = 16;
            this.pictureBox32.TabStop = false;
            this.pictureBox32.Visible = false;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(4, 8);
            this.label90.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(166, 26);
            this.label90.TabIndex = 17;
            this.label90.Text = "Cartas a utilizar:";
            // 
            // lblVidaLava
            // 
            this.lblVidaLava.AutoSize = true;
            this.lblVidaLava.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVidaLava.Location = new System.Drawing.Point(362, 272);
            this.lblVidaLava.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblVidaLava.Name = "lblVidaLava";
            this.lblVidaLava.Size = new System.Drawing.Size(24, 26);
            this.lblVidaLava.TabIndex = 20;
            this.lblVidaLava.Text = "|";
            // 
            // lblDañoLava
            // 
            this.lblDañoLava.AutoSize = true;
            this.lblDañoLava.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDañoLava.Location = new System.Drawing.Point(362, 218);
            this.lblDañoLava.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDañoLava.Name = "lblDañoLava";
            this.lblDañoLava.Size = new System.Drawing.Size(24, 26);
            this.lblDañoLava.TabIndex = 21;
            this.lblDañoLava.Text = "|";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label93.Location = new System.Drawing.Point(357, 163);
            this.label93.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(128, 26);
            this.label93.TabIndex = 18;
            this.label93.Text = "Propiedades:";
            // 
            // btnPvP
            // 
            this.btnPvP.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPvP.Location = new System.Drawing.Point(585, 551);
            this.btnPvP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnPvP.Name = "btnPvP";
            this.btnPvP.Size = new System.Drawing.Size(138, 66);
            this.btnPvP.TabIndex = 5;
            this.btnPvP.Text = "PvP";
            this.btnPvP.UseVisualStyleBackColor = true;
            this.btnPvP.Click += new System.EventHandler(this.btnPvP_Click);
            // 
            // Mazos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.ClientSize = new System.Drawing.Size(1312, 1011);
            this.Controls.Add(this.btnPvP);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Mazos";
            this.Text = "Mazos";
            this.groupBox1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblMonta;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblTronco;
        private System.Windows.Forms.Label lblMosquetera;
        private System.Windows.Forms.Label lblEspiritu;
        private System.Windows.Forms.Label lblGolem;
        private System.Windows.Forms.Label lblBola;
        private System.Windows.Forms.Label lblCañon;
        private System.Windows.Forms.Label lblEsqueleto;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label lblGigante;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label lblEsque;
        private System.Windows.Forms.Label lblTron;
        private System.Windows.Forms.Label lblBandida;
        private System.Windows.Forms.Label lblEsbirros;
        private System.Windows.Forms.Label lblBaby;
        private System.Windows.Forms.Label lblMago;
        private System.Windows.Forms.Label lblRayo;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label lblTorre;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label lblArquero;
        private System.Windows.Forms.Label lblMinero;
        private System.Windows.Forms.Label lblDuendes;
        private System.Windows.Forms.Label lbltroncus;
        private System.Windows.Forms.Label lblTornado;
        private System.Windows.Forms.Label lblValquiria;
        private System.Windows.Forms.Label lblRompe;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label lblMurcielago;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label lblSabueso;
        private System.Windows.Forms.Label lblPrincesa;
        private System.Windows.Forms.Label lblGlobo;
        private System.Windows.Forms.Label lblMini;
        private System.Windows.Forms.Label lblVeneno;
        private System.Windows.Forms.Label lblMega;
        private System.Windows.Forms.Label lblLanzad;
        private System.Windows.Forms.PictureBox pictureBox26;
        private System.Windows.Forms.PictureBox pictureBox27;
        private System.Windows.Forms.PictureBox pictureBox28;
        private System.Windows.Forms.PictureBox pictureBox29;
        private System.Windows.Forms.PictureBox pictureBox30;
        private System.Windows.Forms.PictureBox pictureBox31;
        private System.Windows.Forms.PictureBox pictureBox32;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Button btnPvP;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label label16;
        public System.Windows.Forms.Label label9;
        public System.Windows.Forms.Label lblBalance;
        public System.Windows.Forms.Label lblDefensa;
        public System.Windows.Forms.Label label18;
        public System.Windows.Forms.Label label17;
        public System.Windows.Forms.Label lblBalanceSube;
        public System.Windows.Forms.Label lblDefensaSube;
        public System.Windows.Forms.Label label21;
        public System.Windows.Forms.Label label22;
        public System.Windows.Forms.Label label23;
        public System.Windows.Forms.Label label24;
        public System.Windows.Forms.Label lblVidaSube;
        public System.Windows.Forms.Label lblDañoSube;
        public System.Windows.Forms.Label label47;
        public System.Windows.Forms.Label lblBalanceMinero;
        public System.Windows.Forms.Label lblDefensaMinero;
        public System.Windows.Forms.Label label30;
        public System.Windows.Forms.Label label37;
        public System.Windows.Forms.Label label38;
        public System.Windows.Forms.Label label39;
        public System.Windows.Forms.Label lblVidaMinero;
        public System.Windows.Forms.Label lblDañoMinero;
        public System.Windows.Forms.Label label64;
        public System.Windows.Forms.Label lblBalanceLava;
        public System.Windows.Forms.Label lblDefensaLava;
        public System.Windows.Forms.Label label67;
        public System.Windows.Forms.Label label68;
        public System.Windows.Forms.Label label69;
        public System.Windows.Forms.Label label70;
        public System.Windows.Forms.Label lblVidaLava;
        public System.Windows.Forms.Label lblDañoLava;
        public System.Windows.Forms.Label label93;
        public System.Windows.Forms.TextBox txtVidaSeis;
        public System.Windows.Forms.TextBox txtDañoSeis;
    }
}